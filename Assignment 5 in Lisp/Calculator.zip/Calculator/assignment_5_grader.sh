score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n"
printf " ASSIGNMENT 5\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(10 points) Checking to see if a file called calculator.lisp was submitted\n"
printf "==========\n"
if [ -e calculator.lisp ]
then
    printf "calculator.lisp exists! +10\n"
    let score+=10
else
    printf "Could not find calculator.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(20 points) Trying to compile calculator.lisp.\n"
printf "==========\n"

echo clisp -c calculator.lisp
clisp -c calculator.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +20\n"
    let score+=20
else
    printf "Compile was not successful.\n"
fi


printf "\n\n==========\n"
printf "PART 3:\n"
printf "(20 points) Trying to run calculator.lisp on a simple inputs 10, 5 and '+' to see if it runs. \n"
printf "It should answer \"15\", but we don't care at this point. \n"
printf "==========\n"

printf "Program output was:\n"
clisp calculator.fas <<STDIN
10
5
+
STDIN

if [ $? -eq 0 ]
then
    printf "calculator.lisp ran successfully.  +20\n"
    let score+=20
else
    printf "calculator.lisp did not run successfully.\n"
fi


printf "\n\n==========\n"
printf "PART 4:\n"
printf "(50 points) Running Calculator on 50 test cases.\n"
printf "==========\n"

printf "\n==========\n"
printf "Testing addition\n"
printf "==========\n"

while IFS=" " read x y op actual_answer
do
    submission_answer=`clisp calculator.fas <<STDIN | tail -n 1
${x}
${y}
${op}
STDIN`
    echo "(1 point) testing that inputs ${x} ${y} and ${op} made ${actual_answer}"
    if [ $actual_answer -eq $submission_answer ]
    then
	printf "\t\t\t... your program gave $submission_answer. correct! +1\n"
	let score+=1   
    else
	printf "\t\t\t... your program gave $submission_answer. incorrect! +0\n"
    fi
done < test_cases_addition.csv

printf "\n==========\n"
printf "Testing subtraction\n"
printf "==========\n"

while IFS=" " read x y op actual_answer
do
    submission_answer=`clisp calculator.fas <<STDIN | tail -n 1
${x}
${y}
${op}
STDIN`
    echo "(1 point) testing that inputs ${x} ${y} and ${op} made ${actual_answer}"
    if [ $actual_answer -eq $submission_answer ]
    then
	printf "\t\t\t... your program gave $submission_answer. correct! +1\n"
	let score+=1   
    else
	printf "\t\t\t... your program gave $submission_answer. incorrect! +0\n"
    fi
done < test_cases_subtraction.csv


printf "\n==========\n"
printf "Testing multiplication\n"
printf "==========\n"

while IFS=" " read x y op actual_answer
do
    submission_answer=`clisp calculator.fas <<STDIN | tail -n 1
${x}
${y}
${op}
STDIN`
    echo "(1 point) testing that inputs ${x} ${y} and ${op} made ${actual_answer}"
    if [ $actual_answer -eq $submission_answer ]
    then
	printf "\t\t\t... your program gave $submission_answer. correct! +1\n"
	let score+=1   
    else
	printf "\t\t\t... your program gave $submission_answer. incorrect! +0\n"
    fi
done < test_cases_multiplication.csv

printf "\n==========\n"
printf "Testing division\n"
printf "==========\n"

while IFS=" " read x y op actual_answer
do
    submission_answer=`clisp calculator.fas <<STDIN | tail -n 1
${x}
${y}
${op}
STDIN`
    echo "(1 point) testing that inputs ${x} ${y} and ${op} made ${actual_answer}"
    if [ $actual_answer -eq $submission_answer ]
    then
	printf "\t\t\t... your program gave $submission_answer. correct! +1\n"
	let score+=1   
    else
	printf "\t\t\t... your program gave $submission_answer. incorrect! +0\n"
    fi
done < test_cases_division.csv

printf "\n==========\n"
printf "Testing remainder\n"
printf "==========\n"

while IFS=" " read x y op actual_answer
do
    submission_answer=`clisp calculator.fas <<STDIN | tail -n 1
${x}
${y}
${op}
STDIN`
    echo "(1 point) testing that inputs ${x} ${y} and ${op} made ${actual_answer}"
    if [ $actual_answer -eq $submission_answer ]
    then
	printf "\t\t\t... your program gave $submission_answer. correct! +1\n"
	let score+=1   
    else
	printf "\t\t\t... your program gave $submission_answer. incorrect! +0\n"
    fi
done < test_cases_remainder.csv



printf "\n\n====================\n"
printf "Final score: ${score} out of 100\n"
printf "====================\n\n"

echo $score > points.txt


printf "\n\n============================================================\n"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "calculator.lisp:\n\n"

cat calculator.lisp
