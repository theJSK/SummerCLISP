score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(20 points) Checking to see if a file called divider.lisp was submitted\n"
printf "==========\n"
if [ -e divider.lisp ]
then
    printf "divider.lisp exists! +20\n"
    let score+=20
else
    printf "Could not find divider.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(20 points) Trying to compile divider.lisp \n"
printf "==========\n"

echo clisp -c divider.lisp 
clisp -c divider.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +20\n"
    let score+=20
else
    printf "Compile was not successful.\n"
fi


printf "\n\n==========\n"
printf "PART 3:\n"
printf "(20 points) Trying to run Divider on a simple input 10 and 5 to see if it runs. \n"
printf "It should answer \"2 remainder 0\", but we don't care at this point. \n"
printf "==========\n"

printf "Program output was:\n"
clisp divider.fas <<STDIN
10
5
STDIN

if [ $? -eq 0 ]
then
    printf "divider.lisp ran successfully.  +20\n"
    let score+=20
else
    printf "divider.lisp did not run successfully.\n"
fi


printf "\n\n==========\n"
printf "PART 4:\n"
printf "(40 points) Running Divider on 20 test cases.\n"
printf "==========\n"

## test cases appear as divisor, dividend, quotient, remainder 

while IFS=" " read x y q r
do
    answer=`clisp divider.lisp <<STDIN | tail -n 1
${x}
${y}
STDIN`

    echo "(2 points) testing that inputs ${x} and ${y} gave $q remainder $r"
    IFS=" " read answer_quotient ignore answer_remainder <<<$answer
    if  [[ $q = $answer_quotient && $r = $answer_remainder ]]
    then
	printf "\t\t\t... your program gave $answer. correct! +2\n"
	let score+=2   
    else
	printf "\t\t\t... your program gave $answer. incorrect! +0\n"
    fi
done < test_cases.csv

printf "\n\n====================\n"
printf "Final score: ${score} out of 100\n"
printf "====================\n\n"

echo $score > points.txt

printf "\n\n============================================================"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "divider.lisp:\n\n"

cat divider.lisp

# if need to calculate floating point, use bc
# e.g. bc -l <<< "${score}/7"

# about parsing strings into variables, I also saw this:
# $ v='1.0.65.105'
# $ IFS=. read -a v <<<"$v"
# $ printf '%s\n' "${v[@]}"
# 1
# 0
# 65
# 105

# here was a good page about bash conditional expressions
# http://stackoverflow.com/questions/6270440/simple-logical-operators-in-bash




