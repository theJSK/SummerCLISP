score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n"
printf " ASSIGNMENT 9\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(10 points) Checking to see if a file called looping_multiplier.lisp was submitted\n"
printf "==========\n"
if [ -e looping_multiplier.lisp ]
then
    printf "looping_multiplier.lisp exists! +10\n"
    let score+=10
else
    printf "Could not find looping_multiplier.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(20 points) Trying to compile looping_multiplier.lisp\n"
printf "==========\n"

echo clisp -c looping_multiplier.lisp
clisp -c looping_multiplier.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +20\n"
    let score+=20
else
    printf "Compile was not successful.\n"
fi

printf "\n\n==========\n"
printf "PART 3:\n"
printf "Checking for any asterisks (*) in looping_multiplier.lisp\n"
printf "==========\n"


numberofasterisks=`grep -c \* looping_multiplier.lisp`

if [ $numberofasterisks -gt 0 ]
then
    printf "You have an asterisk in your file!!!  Automatic zero!\n\n"
    printf "Your file has asterisks at these locations:\n"
    grep -n -C 1 \* looping_multiplier.lisp
    score=0
else
    printf "No asterisks found.\n\n"

    printf "\n\n==========\n"
    printf "PART 4:\n"
    printf "(20 points) Trying to run LoopingMultiplier on simple inputs 10, 5 to see if it runs. \n"
    printf "It should answer \"50\", but we don't care at this point. \n"
    printf "==========\n"

    printf "Program output was:\n"
    clisp looping_multiplier.fas <<STDIN
10
5
STDIN

    if [ $? -eq 0 ]
    then
	printf "looping_multiplier.lisp ran successfully.  +20\n"
	let score+=20
    else
	printf "looping_multiplier.lisp did not run successfully.\n"
    fi


    printf "\n\n==========\n"
    printf "PART 5:\n"
    printf "(50 points) Running LoopingMultiplier on 50 test cases.\n"
    printf "==========\n"

    printf "\n==========\n"
    printf "Testing multiplication\n"
    printf "==========\n"

    while IFS=" " read x y actual_answer
    do
	submission_answer=`clisp looping_multiplier.fas <<STDIN | tail -n 1 | tail -c 1000
${x}
${y}
STDIN`
	echo "(1 point) testing that inputs ${x} ${y} returned \"${actual_answer}\""
	if [ "$actual_answer" == "$submission_answer" ]
	then
	    printf "\t\t\t... your program returned \"$submission_answer\". correct! +1\n"
	    let score+=1   
	else
	    printf "\t\t\t... your program returned \"$submission_answer\". incorrect! +0\n"
	fi
    done < test_cases_multiplication.csv
fi
    
printf "\n\n====================\n"
printf "Final score: ${score} out of 100\n"
printf "====================\n\n"

echo $score > points.txt


printf "\n\n============================================================\n"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "looping_multiplier.lisp:\n\n"

cat looping_multiplier.lisp

