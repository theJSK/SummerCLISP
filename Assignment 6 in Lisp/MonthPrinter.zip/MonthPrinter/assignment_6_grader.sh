score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n"
printf " ASSIGNMENT 6\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(5 points) Checking to see if a file called month_printer.lisp was submitted\n"
printf "==========\n"
if [ -e month_printer.lisp ]
then
    printf "month_printer.lisp exists! +5\n"
    let score+=5
else
    printf "Could not find month_printer.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(10 points) Trying to compile month_printer.lisp\n"
printf "==========\n"

echo clisp -c month_printer.lisp
clisp -c month_printer.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +10\n"
    let score+=10
else
    printf "Compile was not successful.\n"
fi


printf "\n\n==========\n"
printf "PART 3:\n"
printf "(10 points) Trying to run month_printer.lisp on a simple input, 10, to see if it runs. \n"
printf "It should answer \"October\", but we don't care at this point. \n"
printf "==========\n"

printf "Program output was:\n"
clisp month_printer.fas <<STDIN
10
STDIN

if [ $? -eq 0 ]
then
    printf "month_printer.lisp ran successfully.  +10\n"
    let score+=10
else
    printf "month_printer.lisp did not run successfully.\n"
fi


printf "\n\n==========\n"
printf "PART 4:\n"
printf "Running month_printer.lisp on 25 test cases.\n"
printf "==========\n"

while IFS=" " read month answer_month
do
    submission_answer=`clisp month_printer.fas <<STDIN | tail -n 1
${month}
STDIN`
    if [ $answer_month == "Invalid" ]
    then
	# this is an invalid month.  We're expecting just the string "Invalid Month"
	echo "(3 points) testing that input ${month} returned \"Invalid Month\"."
	if [ "$submission_answer" == "Invalid Month" ]
	then
	    printf "\t\t\t... your program gave \"${submission_answer}\".  correct! +3\n"
	    let score+=3
	else
	    printf "\t\t\t... your program gave \"${submission_answer}\". incorrect! +0\n"
	fi
    else
	echo "(3 points) testing that input ${month} returned \"${answer_month}\""
	IFS=" " read submission_month <<<$submission_answer
	printf "\t\t\t... your program's full answer was \"$submission_answer\"\n"
	if [ "$submission_answer" == "Invalid Month" ]
	then
	    printf "\t\t\t... But this is a valid month.  incorrect! +0\n"
	else
	    if [ "$submission_month" == "$answer_month" ]
	    then
		printf "\t\t\t... your program gave the month name \"$submission_month\". correct! +3\n"
		let score+=3   
	    else
		printf "\t\t\t... your program gave the month name \"$submission_month\". incorrect! +0\n"
	    fi
	fi
    fi
done < test_cases.csv

printf "\n\n====================\n"
printf "Final score: ${score} out of 100\n"
printf "====================\n\n"

echo $score > points.txt


printf "\n\n============================================================\n"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "month_printer.lisp:\n\n"

cat month_printer.lisp
