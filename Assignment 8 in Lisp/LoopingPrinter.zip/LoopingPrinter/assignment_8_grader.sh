score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n"
printf " ASSIGNMENT 8\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(10 points) Checking to see if a file called looping_printer.lisp was submitted\n"
printf "==========\n"
if [ -e looping_printer.lisp ]
then
    printf "looping_printer.lisp exists! +10\n"
    let score+=10
else
    printf "Could not find looping_printer.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(20 points) Trying to compile looping_printer.lisp\n"
printf "==========\n"

echo clisp -c looping_printer.lisp
clisp -c looping_printer.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +20\n"
    let score+=20
else
    printf "Compile was not successful.\n"
fi

printf "\n\n==========\n"
printf "PART 3:\n"
printf "(20 points) Trying to run LoopingPrinter on simple input 5 to see if it runs. \n"
printf "It should answer \"LispLispLispLispLisp\", but we don't care at this point. \n"
printf "==========\n"

printf "Program output was:\n"
clisp looping_printer.fas <<STDIN
5
STDIN
if [ $? -eq 0 ]
then
    printf "\nlooping_printer.lisp ran successfully.  +20\n"
    let score+=20
else
    printf "\nlooping_printer.lisp did not run successfully.\n"
fi


printf "\n\n==========\n"
printf "PART 4:\n"
printf "(50 points) Running LoopingPrinter on 25 test cases.\n"
printf "==========\n"

while IFS=" " read x actual_answer
do
    submission_answer=`clisp looping_printer.fas <<STDIN  | tail -n 1 | tail -c 1000
${x}
STDIN`
    echo "(2 point) testing that input ${x} returned \"${actual_answer}\""
    if [ "$actual_answer" == "$submission_answer" ]
    then
	printf "\t\t\t... your program returned \"$submission_answer\". correct! +2\n"
	let score+=2
    else
	printf "\t\t\t... your program returned \"$submission_answer\". incorrect! +0\n"
    fi
done < test_cases_loops.csv
    
printf "\n\n====================\n"
printf "Final score: ${score} out of 100\n"
printf "====================\n\n"

echo $score > points.txt


printf "\n\n============================================================\n"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "looping_printer.lisp:\n\n"

cat looping_printer.lisp
