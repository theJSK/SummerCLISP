score=0
printf "====================\n"
printf " AUTOGRADER RESULTS\n"
printf "====================\n"
printf " ASSIGNMENT 7\n"
printf "====================\n\n"

printf "==========\n"
printf "PART 1:\n"
printf "(10 points) Checking to see if a file called date_printer.lisp was submitted\n"
printf "==========\n"
if [ -e date_printer.lisp ]
then
    printf "date_printer.lisp exists! +10\n"
    let score+=10
else
    printf "Could not find date_printer.lisp.  It wasn't submitted?\n"
fi

printf "\n\n==========\n"
printf "PART 2:\n"
printf "(20 points) Trying to compile date_printer.lisp\n"
printf "==========\n"

echo clisp -c date_printer.lisp
clisp -c date_printer.lisp

if [ $? -eq 0 ]
then
    printf "Compile was successful.  +20\n"
    let score+=20
else
    printf "Compile was not successful.\n"
fi


printf "\n\n==========\n"
printf "PART 3:\n"
printf "(20 points) Trying to run date_printer.lisp on a simple inputs 10 and 5 to see if it runs. \n"
printf "It should answer \"October 5th\", but we don't care at this point. \n"
printf "==========\n"

printf "Program output was:\n"
clisp date_printer.fas <<STDIN
10
5
STDIN

if [ $? -eq 0 ]
then
    printf "date_printer.lisp ran successfully.  +20\n"
    let score+=20
else
    printf "date_printer.lisp did not run successfully.\n"
fi


printf "\n\n==========\n"
printf "PART 4:\n"
printf "Running date_printer.lisp on 155 test cases.\n"
printf "==========\n"

while IFS=" " read month day answer_month answer_day_number answer_day_suffix
do
    submission_answer=`clisp date_printer.fas <<STDIN | tail -n 1
${month}
${day}
STDIN`
    if [ $answer_month == "Invalid" ]
    then
	# this is an invalid date.  We're expecting just the string "Invalid Date"
	echo "(5 points) testing that inputs ${month} ${day} returned \"Invalid Date\"."
	if [ "$submission_answer" == "Invalid Date" ]
	then
	    printf "\t\t\t... your program gave \"${submission_answer}\".  correct! +5\n"
	    let score+=5   
	else
	    printf "\t\t\t... your program gave \"${submission_answer}\". incorrect! +0\n"
	fi
    else
	echo "(5 points) testing that inputs ${month} ${day} returned \"${answer_month} ${answer_day_number}${answer_day_suffix}\""
	IFS=" " read submission_month submission_day <<<$submission_answer
	printf "\t\t\t... your program's full answer was \"$submission_answer\"\n"
	if [ "$submission_answer" == "Invalid Date" ]
	then
	    "\t\t\t... But this is a valid date.  incorrect! +0\n"
	else
	    if [ "$submission_month" == "$answer_month" ]
	    then
		printf "\t\t\t... your program gave the month name \"$submission_month\". correct! +2\n"
		let score+=2   
	    else
		printf "\t\t\t... your program gave the month name \"$submission_month\". incorrect! +0\n"
	    fi
	    submission_day_number=`echo "$submission_day" | egrep -o '[0-9]*' | head -n 1`
	    submission_day_suffix=`echo "$submission_day" | egrep -o 'st|nd|rd|th' | head -n 1` 
	    if [ "$submission_day_number" == "$answer_day_number" ]
	    then
		printf "\t\t\t... your program gave the day \"$submission_day_number\". correct! +1\n"
		let score+=1   
	    else
		printf "\t\t\t... your program gave the day \"$submission_day_number\". incorrect! +0\n"
	    fi
	    
	    if [ "$submission_day_suffix" == "$answer_day_suffix" ]
	    then
		printf "\t\t\t... your program gave the suffix \"$submission_day_suffix\". correct! +2\n"
		let score+=2   
	    else
		printf "\t\t\t... your program gave the suffix \"$submission_day_suffix\". incorrect! +0\n"
	    fi
	fi
    fi
done < test_cases.csv

scaled_score=`bc <<< "${score}/8.25"`

printf "\n\n====================\n"
printf "Final score: ${score} out of 825\n"
printf "           = ${scaled_score} out of 100\n"
printf "====================\n\n"

echo $scaled_score > points.txt


printf "\n\n============================================================\n"
printf "============================================================\n"

printf "\n\n====================\n"
printf "Text of submitted files\n"
printf "====================\n"
printf "date_printer.lisp:\n\n"

cat date_printer.lisp
